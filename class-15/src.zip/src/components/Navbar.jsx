import React, { useContext } from 'react'
import { ThemeDataContext } from '../context/ThemeContext'

 const data = useContext(ThemeDataContext);
const Navbar = () => {
  return (
    <div className='nav'>
      <h1>Navbar-{data}</h1>
    </div>
  )
}

export default Navbar
