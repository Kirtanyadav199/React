import React, { createContext } from 'react'

  export const ThemeDataContext =   createContext();

const ThemeContext = (props) => {

const data = 'Kirtan';
  return (
    <div>
    <ThemeDataContext.Provider value={data}>
        {props.children}
    </ThemeDataContext.Provider>
    </div>
  )
}

export default ThemeContext
